package tp1.enonce.multimedia;

public interface Etat {
	

public void pause(MediaContext contexte, MediaPlayer player, String titre,
		String auteur, String categorie, int taille, Object contenu);
public void resume(MediaContext contexte, MediaPlayer player, String titre,
		String auteur, String categorie, int taille, Object contenu);
public void stop(MediaContext contexte, MediaPlayer player, String titre,
		String auteur, String categorie, int taille, Object contenu);
void start(MediaContext contexte, MediaPlayer player, String titre,
		String auteur, String categorie, int taille, Object contenu);
public int getEtat();
}
