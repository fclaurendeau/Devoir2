package tp1.enonce.multimedia;

public class QuickTimeManager  extends MultimediaManager {

	public QuickTimeManager( String auteur,
			String titre, int taille, Object contenu) {
		super(false, 0,  auteur, titre, ".mov",taille, contenu);
		player = QuickTime.PLAYER;
	}

}
