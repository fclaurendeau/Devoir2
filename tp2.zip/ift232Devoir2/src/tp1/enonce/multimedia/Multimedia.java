package tp1.enonce.multimedia;

public interface Multimedia {
    String getTitre();
    String getAuteur();
    boolean isGratuit();
    boolean isLocation();
    boolean isAchat();
    String getProprietaire();
}

