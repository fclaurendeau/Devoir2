package tp1.enonce.multimedia;

public class EtatPlaying  implements Etat{
	


	public EtatPlaying() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void pause(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		contexte.augmenteUtilisation();
		player.pause(titre, auteur, categorie, taille, contenu);
		contexte.setEtatDuMedia(new EtatPaused());
	}

	@Override
	public void resume(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		contexte.augmenteUtilisation();
		player.close(titre, auteur, categorie, taille, contenu);
		contexte.setEtatDuMedia(new EtatStopped() );
		
	}

	@Override
	public void start(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getEtat() {
		return MultimediaManager.PLAYING;
	}

}
