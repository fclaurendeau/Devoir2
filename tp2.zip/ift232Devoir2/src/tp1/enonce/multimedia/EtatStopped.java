package tp1.enonce.multimedia;

public class EtatStopped extends EtatCreated  {
	

	public EtatStopped() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public int getEtat() {
		return MultimediaManager.STOPPED;
	}


}
