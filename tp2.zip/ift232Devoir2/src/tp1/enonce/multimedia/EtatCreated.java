package tp1.enonce.multimedia;

public class EtatCreated  implements Etat{
	

	public EtatCreated() {
	}

	

	@Override
	public void pause(MediaContext contexte,MediaPlayer player, String titre, String auteur,
			String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume(MediaContext contexte,MediaPlayer player, String titre, String auteur,
			String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop(MediaContext contexte,MediaPlayer player, String titre, String auteur,
			String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void start(MediaContext contexte,MediaPlayer player, String titre, String auteur,
			String categorie, int taille, Object contenu) {
		player.play(titre, auteur, categorie, taille, contenu);
		contexte.setEtatDuMedia(new EtatPlaying());
		
	}



	@Override
	public int getEtat() {
		return MultimediaManager.CREATED;
	}

}
