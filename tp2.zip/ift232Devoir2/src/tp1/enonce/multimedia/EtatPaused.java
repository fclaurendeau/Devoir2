package tp1.enonce.multimedia;

public class EtatPaused implements Etat{
	


	public EtatPaused() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void pause(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		contexte.reduitUtilisation();
		player.play(titre, auteur, categorie, taille, contenu);
		contexte.setEtatDuMedia(new EtatPlaying());
	}

	@Override
	public void stop(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void start(MediaContext contexte, MediaPlayer player, String titre,
			String auteur, String categorie, int taille, Object contenu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getEtat() {
		return MultimediaManager.PAUSED;
	}

}
