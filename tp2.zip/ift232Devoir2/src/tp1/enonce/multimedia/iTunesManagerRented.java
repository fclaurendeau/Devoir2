package tp1.enonce.multimedia;

public class iTunesManagerRented extends iTunesManager{

	public iTunesManagerRented(int maximum ,String auteur,
			String titre, int taille, Object contenu) {
		super(auteur,
				titre, taille, contenu);
			this.setLocation(true);
			if (maximum < 1) this.setMaximum(1);
			else this.setMaximum(maximum) ;
	}
	
	public void start() {

		// cette méthode ne peut être invoquée
		// que pour démarrer la lecture du document multimédia
		if (this.getUtilisation() == this.getMaximum()) {
			return;
		}
		super.start();
		
		// l'état de l'instance est PLAYING
	}

}
