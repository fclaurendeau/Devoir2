package tp1.enonce.multimedia;

public class iTunesManager extends MultimediaManager{

	public iTunesManager(String auteur,
			String titre, int taille, Object contenu) {
		super(false, 0,  auteur, titre, ".mp3",taille, contenu);
		player = iTunes.PLAYER;
	}

}
