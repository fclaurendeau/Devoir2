package tp1.enonce.multimedia;
/**
 * Fait par Francois Laurendeau 14 019 046
 */

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
//import org.junit.Ignore;
import org.junit.Test;

public class MultimediaManagerTest {
	MultimediaManager mm1,mm2,mm3, mm4;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		mm1 = new QuickTimeManagerRented(2,"auteurA", "titre1",  120, "FILM");
		mm2 = new iTunesManager("auteurB", "titre2",  4, "Musique");
		mm3 = new iTunesManagerRented( 2, "auteurB", "titre3",  4, "Musique");
		mm4 = new QuickTimeManagerRented( 0, "auteurB", "titre3",  180 , "FILM");

	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test que le decompte de l'utilisation respecte le maximum lors d'une location
	 */
	@Test
	public void testMaximumLocation() {
		mm1.start();
		mm1.stop();
		mm1.start();
		mm1.stop();
		mm1.start();
		mm1.stop();
		mm1.start();
		mm1.stop();
		mm1.start();
		mm1.stop();
		assertTrue(mm1.getUtilisation() == 2);
		System.out.println("< Maximum bien respecte  > " + mm1);
	}
	/**
	 * Maximum respecte et etat reste a STOPPED apres l'atteinte du maximum -  VIDEO
	 */
	
	@Test
	public void testMaximumLocationRespecteVideo() {
		mm1.start();
		assertTrue(mm1.getEtat() == MultimediaManager.PLAYING);
		mm1.stop();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		mm1.start();
		assertTrue(mm1.getEtat() == MultimediaManager.PLAYING);
		mm1.stop();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		mm1.start();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED); // verifie que reste a "STOPPED:
		mm1.stop();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		mm1.start();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		mm1.stop();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		mm1.start();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		mm1.stop();
		assertTrue(mm1.getEtat() == MultimediaManager.STOPPED);
		assertTrue(mm1.getUtilisation() == 2);
		System.out.println("< Maximum respecte et reste a STOPPED  video > " + mm1);
	}
	
	/**
	 * Maximum respecte et etat reste a STOPPED apres l'atteinte du maximum -  MP3
	 */
	@Test
	public void testMaximumLocationRespecteMP3() {
		mm3.start();
		assertTrue(mm3.getEtat() == MultimediaManager.PLAYING);
		mm3.stop();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		mm3.start();
		assertTrue(mm3.getEtat() == MultimediaManager.PLAYING);
		mm3.stop();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		mm3.start();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED); // verifie que reste a "STOPPED:
		mm3.stop();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		mm3.start();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		mm3.stop();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		mm3.start();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		mm3.stop();
		assertTrue(mm3.getEtat() == MultimediaManager.STOPPED);
		assertTrue(mm3.getUtilisation() == 2);
		System.out.println("< Maximum respecte et reste a STOPPED  MP3 > " + mm3);
	}
	
	/**
	 * Test qu'il n'y a pas de limite,pour le decompte de l'utilisation, lorsque le media n'est pas en location (achat ou gratuit)
	 */
	@Test
	public void testMaximumAchete() {
		mm2.start();
		mm2.stop();
		mm2.start();
		mm2.stop();
		mm2.start();
		mm2.stop();
		mm2.start();
		mm2.stop();
		mm2.start();
		mm2.stop();
		System.out.println("< Pas en location  > " + mm2);
		assertTrue(mm2.getUtilisation() == 5);
	}
	
	/**
	 * Test qu'il y a vraiement une utilisation sans limite si non en location, que l'on peut effectuer plusieur lecture du media (PLAYING)
	 */
	@Test
	public void testUtilisationAcheteSansLimite() {
		mm2.start();
		assertTrue(mm2.getEtat() == MultimediaManager.PLAYING);
		mm2.stop();
		assertTrue(mm2.getEtat() == MultimediaManager.STOPPED);
		mm2.start();
		assertTrue(mm2.getEtat() == MultimediaManager.PLAYING);
		mm2.stop();
		assertTrue(mm2.getEtat() == MultimediaManager.STOPPED);
		mm2.start();
		assertTrue(mm2.getEtat() == MultimediaManager.PLAYING);
		mm2.stop();
		assertTrue(mm2.getEtat() == MultimediaManager.STOPPED);
		mm2.start();
		assertTrue(mm2.getEtat() == MultimediaManager.PLAYING);
		mm2.stop();
		assertTrue(mm2.getEtat() == MultimediaManager.STOPPED);
		mm2.start();
		assertTrue(mm2.getEtat() == MultimediaManager.PLAYING);
		mm2.stop();
		assertTrue(mm2.getEtat() ==MultimediaManager.STOPPED);
		System.out.println("< Utilisation sans limite  > " + mm2);
		assertTrue(mm2.getUtilisation() == 5);
	}
	
	
	/**
	 * Une utilisation : Start Pause Resume Stop
	 */
	@Test
	public void testSartPauseResumeStopLocation() {
		mm1.start();
		mm1.pause();
		mm1.resume();
		mm1.stop();
		assertTrue(mm1.getUtilisation() == 1);
		System.out.println("<Pause Resume > " + mm1);
	}
	
	/**
	 * Une utilisation : START, PAUSE, RESUME, PAUSE, RESUME, STOP
	 */
	@Test
	public void testStartPauseResumePauseResumeStopLocation() {
		mm1.start();
		mm1.pause();
		mm1.resume();
		mm1.pause();
		mm1.resume();
		mm1.stop();
		assertTrue(mm1.getUtilisation() == 1);
		System.out.println("<Pause Resume Successif > "+mm1);
	}
	

	/**
	 * Une utilisation : START, PAUSE, RESUME, PAUSE ( sans stop)
	 */
	@Test
	public void testStartPauseResumePauseLocation() {
		mm1.start();
		mm1.pause();
		mm1.resume();
		mm1.pause();
		assertTrue(mm1.getUtilisation() == 1);
		System.out.println("<Pause Resume sans stop> "+mm1);
	}
	
	/**
	 * Test utilisation erronnee - Pause successif
	 */
	@Test
	public void testStartPauseResumePausePauseResumeStopLocation() {
		mm1.start();
		mm1.pause();
		mm1.resume();
		mm1.pause();
		assertTrue(mm1.getUtilisation() == 1);
		mm1.pause();
		assertTrue(mm1.getUtilisation() == 1);
		mm1.resume();
		assertTrue(mm1.getUtilisation() == 0);
		mm1.stop();
		assertTrue(mm1.getUtilisation() == 1);
		System.out.println("<Test erreur - Pause successif> "+ mm1);
	}
	
	/**
	 * Test utilisation erronnee-  RESUME successif apres STOP
	 */
	@Test
	public void testPlayStopResumeResumeStopResumeStopResumeStopStartStopLocation() {
		mm1.start();
		mm1.stop();
		assertTrue(mm1.getUtilisation() == 1);
		mm1.resume();
		assertTrue(mm1.getUtilisation() == 1);
		mm1.resume();
		assertTrue(mm1.getUtilisation() == 1);
		mm1.stop();
		assertTrue(mm1.getUtilisation() == 1);
		mm1.resume();
		mm1.stop();
		mm1.resume();
		mm1.stop();
		mm1.start();
		mm1.stop();
		System.out.println("<Test erreur - Stop Resume successif> "+mm1);
		assertTrue(mm1.getUtilisation() == 2);
		
	}
	
	/**
	 * 	Test de start successif sans stop pour revisionner un film louer plus que la maximum
	 */
	@Test
	public void testStartStartStartLocation() {
		mm1.start();
		assertTrue(mm1.getUtilisation() == 0);
		mm1.start();
		assertTrue(mm1.getUtilisation() == 0);
		
		System.out.println("<Test erreur - Start successif> "+mm1);
		assertTrue(mm1.getUtilisation() == 0);
		
	}
	
	/**
	 * Une utilisation unique si maximum a zero : Start Pause Resume Stop Start Stop
	 */
	@Test
	public void testMaximumZeroSartPauseResumeStopStartStopLocation() {
		mm4.start();
		mm4.pause();
		mm4.resume();
		mm4.stop();
		mm4.start();
		mm4.stop();
		assertTrue(mm4.getUtilisation() == 1);
		System.out.println("<Maximum null Start Pause Resume Stop Start Stop en location  > " + mm4);
	}

}
