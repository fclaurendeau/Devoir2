package tp1.enonce.multimedia;

public class QuickTimeManagerRented extends QuickTimeManager {

	public QuickTimeManagerRented(int maximum ,String auteur,
			String titre, int taille, Object contenu) {
		super(auteur,
			titre, taille, contenu);
		this.setLocation(true);
		if (maximum < 1) this.setMaximum(1);
		else this.setMaximum(maximum) ;
		
		// TODO Auto-generated constructor stub
	}
	
	public void start() {

		// cette méthode ne peut être invoquée
		// que pour démarrer la lecture du document multimédia
		if (this.getUtilisation() == this.getMaximum()) {
			return;
		}
		
		super.start();

		
		// l'état de l'instance est PLAYING
	}

}
