package tp1.enonce.multimedia;
/**
 * 
 * @author francoislaurendeau 14 019 046
 *
 */
public abstract class MultimediaManager {
	public final static int CREATED = 1;
	public final static int PLAYING = 3;
	public final static  int PAUSED = 2;
	public final static int STOPPED = 4;
	private int maximum;
	private boolean location;

	private String auteur;
	private String titre;
	private String categorie; 
	private int taille;
	private Object contenu;

	protected MediaPlayer player;
	
	private MediaContext contexte; // Pour gerer les etats

	@Override
	public String toString() {
		return "MultimediaManager [etat=" + contexte.getEtat() + ", maximum=" + maximum
				+ ", utilisation=" + contexte.getUtilisation() + ", location=" + location
				+ ", auteur=" + auteur + ", titre=" + titre + ", categorie="
				+ categorie + ", taille=" + taille + ", contenu=" + contenu
				+ ", player=" + player + "]";
	}

	/**
	 * s'il s'agit d'une location, la variable utilisation_ ne doit jamais être
	 * supérieure à maximum_
	 * 
	 * s'il s'agit d'une location, la variable d'instance maximum_ doit être
	 * supérieure à 0
	 * 
	 * s'il s'agit d'une location, la valeur de la variable d'instance
	 * utilisation_ correspond à la différence entre le nombre d'invocations des
	 * méthodes pause() et stop() et le nombre d'invocations de la méthode
	 * resume()
	 */

	public MultimediaManager(boolean location, int maximum, String auteur,
			String titre, String categorie, int taille, Object contenu) {
		this.location = location;
		this.maximum = maximum;
		this.auteur = auteur;
		this.titre = titre;
		this.categorie = categorie;
		this.taille = taille;
		this.contenu = contenu;
		this.contexte = new MediaContext();
	}
	
	public int getMaximum() {
		return maximum;
	}

	public void setMaximum(int maximum) {
		this.maximum = maximum;
	}

	public boolean isLocation() {
		return location;
	}

	public void setLocation(boolean location) {
		this.location = location;
	}

	/**
	 * cette méthode ne peut être invoquée
	 * que pour démarrer la lecture du document multimédia
	 * l'état de l'instance est PLAYING apres start()
	 */
	public void start() {
		contexte.start(contexte,player,titre, auteur, categorie, taille, contenu);
	}
	
	/**
	 * l'instance doit être dans l'état PLAYING
	 * pour que l'opération pause() soit valide
	 */
	public void pause() {
		contexte.pause(contexte, player, titre, auteur, categorie, taille, contenu);
		
	}
	
	/**
	 * L'operation resume()  n'est valide qu'après une pause
	 */
	public void resume() {
		contexte.resume(contexte, player, titre, auteur, categorie, taille, contenu);
	}

	/**
	 * le contenu doit jouer pour que cette opération soit valide
	 * l'état de l'instance est STOPPED apres le stop()
	 * le nombre d'utilisation est incrémentée de 1
	 */
	public void stop() {
		contexte.stop(contexte,player,titre, auteur, categorie, taille, contenu); 
	}
	
	public int getUtilisation(){
		return contexte.getUtilisation();
	}
	
	public int getEtat(){
		return contexte.getEtat();
	}

}
