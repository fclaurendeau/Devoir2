package tp1.enonce.multimedia;

public class MediaContext implements Etat{
	
	private Etat etatDuMedia;
	private int utilisation;

	public MediaContext()  {
		setEtatDuMedia(new EtatCreated());
		this.utilisation = 0;
	}
	
	public Etat getEtatDuMedia() {
		return etatDuMedia;
	}

	public void setEtatDuMedia(Etat etatDuMedia) {
		this.etatDuMedia = etatDuMedia;
	}

	@Override
	public void start(MediaContext contexte, MediaPlayer player, String titre, String auteur, String categorie, int taille, Object contenu) {
		this.etatDuMedia.start(contexte, player, titre,  auteur,  categorie,  taille,  contenu);	
	}

	@Override
	public void pause(MediaContext contexte, MediaPlayer player, String titre, String auteur, String categorie, int taille, Object contenu) {
		this.etatDuMedia.pause(contexte, player, titre,  auteur,  categorie,  taille,  contenu);
	}

	@Override
	public void resume(MediaContext contexte, MediaPlayer player, String titre, String auteur, String categorie, int taille, Object contenu) {
		this.etatDuMedia.resume(contexte, player, titre,  auteur,  categorie,  taille,  contenu);
	}

	@Override
	public void stop(MediaContext contexte, MediaPlayer player, String titre, String auteur, String categorie, int taille, Object contenu) {
		this.etatDuMedia.stop(contexte, player, titre,  auteur,  categorie,  taille,  contenu);
	}

	void reduitUtilisation() {
		utilisation--;
	}

	void augmenteUtilisation() {
		utilisation++;
	}

	public int getUtilisation() {
		return utilisation;
	}

	public void setUtilisation(int utilisation) {
		this.utilisation = utilisation;
	}

	@Override
	public int getEtat() {
		return this.etatDuMedia.getEtat();
	}
}
